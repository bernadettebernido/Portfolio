# 01 — Retail Sales Analysis

**Status:** Practice project — analysis not yet completed  
**Dataset:** `data/retail_sales_sample.csv` (synthetic sample data)  
**Tools:** Excel, SQL, Power BI, Python

## Business scenario
A fictional small retailer wants a clear view of sales performance across products, categories, regions, and channels.

## Questions
1. What are total net sales and order count?
2. Which products and categories contribute the most net sales?
3. How do sales compare by region and channel?
4. Are there monthly patterns or unusually strong/weak periods?
5. What additional data is needed to assess discount effectiveness?

## Data dictionary
`order_id` (sample ID), `order_date`, `region`, `sales_channel`, `product`, `category`, `quantity`, `list_unit_price`, `discount_rate` (e.g. 0.10 = 10%), `net_sales` (quantity × price after discount).

## Dashboard concept
- KPI cards: Net Sales, Orders, Units Sold, Average Order Value.
- Line chart: net sales by month.
- Bar chart: net sales by product/category.
- Column chart: net sales by region.
- Stacked bar: channel by category.
- Slicers: date, region, category, channel.

## Workflow
1. Check missing values, duplicate IDs, date formats, and numeric types.
2. Recalculate `net_sales` from quantity, list price, and discount; check rounding.
3. Import the CSV as `retail_sales` and run `sql/retail_sales_queries.sql`.
4. Use Excel PivotTables to independently verify key totals.
5. Build a Power BI report and write verified findings in `findings.md`.

## Insight template
- **Observation:** What does the query/chart show?
- **Evidence:** Metric, time period, segment, and calculated value.
- **Possible explanation:** A cautious interpretation, not a proven cause.
- **Next question:** What additional data would help?

Do not fill in results until you run the analysis. This is fictional practice data, not real company data.
