# Findings — Retail Sales Analysis

**Status:** Complete this after running and validating the analysis.

## Executive summary
[Write 2–3 sentences summarizing verified findings.]

## Key findings
1. Product/category: [calculated evidence]
2. Region/channel: [calculated evidence]
3. Monthly trend: [calculated evidence]

## Recommendation
[One practical recommendation supported by the data.]

## Limitations
- Synthetic practice dataset, not real business activity.
- No costs, inventory, returns, or marketing spend.
- Observed patterns do not establish causation.
