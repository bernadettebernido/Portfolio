"""Starter analysis for a synthetic retail sales dataset."""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA = Path(__file__).parents[1] / "data" / "retail_sales_sample.csv"

def main():
    df = pd.read_csv(DATA, parse_dates=["order_date"])
    print("Preview:\n", df.head())
    print("\nMissing values:\n", df.isna().sum())
    print("\nKPIs for synthetic practice data")
    print(f"Net sales: {df['net_sales'].sum():,.2f}")
    print(f"Orders: {df['order_id'].nunique():,}")
    print(f"Units sold: {df['quantity'].sum():,}")
    print(f"Average order value: {df['net_sales'].mean():,.2f}")
    monthly = df.assign(month=df["order_date"].dt.to_period("M").astype(str))
    totals = monthly.groupby("month", as_index=False)["net_sales"].sum()
    ax = totals.plot(x="month", y="net_sales", kind="line", marker="o",
                     title="Monthly Net Sales — Synthetic Sample")
    ax.set_xlabel("Month"); ax.set_ylabel("Net sales")
    plt.xticks(rotation=45, ha="right"); plt.tight_layout()
    output = Path(__file__).parents[1] / "images" / "monthly_sales.png"
    output.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output, dpi=160)
    print(f"Chart saved to {output}")

if __name__ == "__main__":
    main()
