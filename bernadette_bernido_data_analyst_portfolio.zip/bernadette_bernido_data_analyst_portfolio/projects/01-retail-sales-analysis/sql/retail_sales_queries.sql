-- Import CSV as a table named retail_sales. Syntax may vary by database.
SELECT * FROM retail_sales LIMIT 10;

-- Check duplicate order IDs
SELECT order_id, COUNT(*) AS row_count
FROM retail_sales GROUP BY order_id HAVING COUNT(*) > 1;

-- Overall KPIs
SELECT ROUND(SUM(net_sales), 2) AS total_net_sales,
       COUNT(DISTINCT order_id) AS order_count,
       SUM(quantity) AS units_sold,
       ROUND(AVG(net_sales), 2) AS average_order_value
FROM retail_sales;

-- Sales by category
SELECT category, ROUND(SUM(net_sales), 2) AS net_sales, SUM(quantity) AS units_sold
FROM retail_sales GROUP BY category ORDER BY net_sales DESC;

-- Sales by region and channel
SELECT region, sales_channel, ROUND(SUM(net_sales), 2) AS net_sales
FROM retail_sales GROUP BY region, sales_channel ORDER BY region, net_sales DESC;

-- Monthly trend (SQLite date syntax)
SELECT strftime('%Y-%m', order_date) AS sales_month, ROUND(SUM(net_sales), 2) AS net_sales
FROM retail_sales GROUP BY strftime('%Y-%m', order_date) ORDER BY sales_month;

-- Check provided net sales against recalculation
SELECT order_id, net_sales,
       ROUND(quantity * list_unit_price * (1 - discount_rate), 2) AS recalculated_net_sales
FROM retail_sales
WHERE ABS(net_sales - ROUND(quantity * list_unit_price * (1 - discount_rate), 2)) > 0.02;
