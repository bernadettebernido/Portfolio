# 02 — Customer Retention Analysis

**Status:** Practice project — analysis not yet completed  
**Dataset:** `data/customer_retention_sample.csv` (synthetic sample data)  
**Tools:** SQL, Excel, Python, Power BI

## Business scenario
A fictional subscription business wants to understand how customer churn differs by plan, tenure, and recent support-ticket volume.

## Questions
1. What share of sample customers are marked as churned?
2. How does churn differ by plan type?
3. Is churn different for newer versus longer-tenured customers?
4. How does churn vary with support-ticket volume?
5. What other fields are needed before making recommendations?

## Data dictionary
`customer_id` (synthetic ID), `tenure_months`, `plan_type`, `monthly_fee`, `support_tickets_last_6m`, `churned` (Yes/No).

## Dashboard concept
- KPI cards: Customers, Churned Customers, Churn Rate, Average Tenure.
- Bar chart: churn rate by plan.
- Column chart: churn by tenure band.
- Bar chart: support-ticket band vs churn rate.
- Slicers: plan type and tenure band.

## Workflow
Check missing values and duplicate IDs, calculate overall and segment churn rates, validate in Excel/Power BI, and document verified results in `findings.md`.

The dataset is artificially generated for learning. Do not present it as data from a real company or use it for real customer decisions.
