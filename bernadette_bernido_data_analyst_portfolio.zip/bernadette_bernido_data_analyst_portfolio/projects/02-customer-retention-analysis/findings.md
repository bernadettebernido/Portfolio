# Findings — Customer Retention Analysis

**Status:** Complete after analysis.

- Overall churn rate: [calculate and verify]
- Plan comparison: [counts and percentages]
- Tenure comparison: [counts and percentages]
- Support-ticket comparison: [describe association carefully]

## Recommendation
[Suggest a test or follow-up investigation; do not claim causation.]

## Limitations
Synthetic sample, artificially generated outcomes, small sample size, and missing context such as acquisition channel, feedback, contract type, and churn reasons. Correlation does not prove causation.
