-- Import CSV as customer_retention.
SELECT COUNT(*) AS customer_count,
       SUM(CASE WHEN churned = 'Yes' THEN 1 ELSE 0 END) AS churned_customers,
       ROUND(100.0 * SUM(CASE WHEN churned = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS churn_rate_pct
FROM customer_retention;

SELECT plan_type, COUNT(*) AS customers,
       SUM(CASE WHEN churned = 'Yes' THEN 1 ELSE 0 END) AS churned_customers,
       ROUND(100.0 * SUM(CASE WHEN churned = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS churn_rate_pct
FROM customer_retention GROUP BY plan_type ORDER BY churn_rate_pct DESC;

SELECT CASE WHEN tenure_months < 6 THEN '0–5 months'
            WHEN tenure_months < 13 THEN '6–12 months'
            WHEN tenure_months < 25 THEN '13–24 months'
            ELSE '25+ months' END AS tenure_band,
       COUNT(*) AS customers,
       ROUND(100.0 * SUM(CASE WHEN churned = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS churn_rate_pct
FROM customer_retention GROUP BY tenure_band ORDER BY MIN(tenure_months);

SELECT CASE WHEN support_tickets_last_6m = 0 THEN '0 tickets'
            WHEN support_tickets_last_6m <= 2 THEN '1–2 tickets'
            ELSE '3+ tickets' END AS support_ticket_band,
       COUNT(*) AS customers,
       ROUND(100.0 * SUM(CASE WHEN churned = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS churn_rate_pct
FROM customer_retention GROUP BY support_ticket_band;
