# 03 — HR Attrition Exploration

**Status:** Practice project — analysis not yet completed  
**Dataset:** `data/hr_attrition_sample.csv` (synthetic sample data)  
**Tools:** Excel, SQL, Power BI, Python

## Business scenario
A fictional organization wants a descriptive overview of employee attrition across departments, tenure, job satisfaction, and overtime.

## Questions
1. What is the sample attrition rate?
2. How does attrition vary by department?
3. Is attrition different across satisfaction scores?
4. How does attrition vary by overtime and tenure?
5. What context is needed before interpreting these patterns?

## Data dictionary
`employee_id` (synthetic ID), `age`, `department`, `years_at_company`, `job_satisfaction_1_to_5`, `overtime`, `monthly_salary` (currency unspecified), `attrition` (Yes/No).

## Dashboard concept
- KPI cards: Employees, Attrition Count, Attrition Rate, Average Tenure.
- Bar chart: attrition rate by department.
- Column chart: attrition rate by satisfaction score.
- Bar chart: attrition by overtime status.
- Tenure distribution by attrition status.
- Slicers: department, overtime, tenure band.

## Responsible analysis
This is synthetic learning data, not employee information from a real organization. Avoid using demographic fields for individual employment decisions. Show group sizes beside percentages, and do not infer causation from descriptive patterns.

## Workflow
Review data quality, define attrition rate, calculate summaries in SQL, validate totals with Excel, build a Power BI report, and add only verified observations to `findings.md`.
