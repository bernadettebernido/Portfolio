# Findings — HR Attrition Exploration

**Status:** Complete after analysis.

- Overall sample attrition rate: [calculate and verify]
- Department differences: [group sizes and percentages]
- Satisfaction patterns: [group sizes and percentages]
- Overtime comparison: [group sizes and percentages]

## Interpretation and limitations
Explain that descriptive associations do not establish causes. Note the synthetic data, sample size, and missing context.

## Follow-up questions
Are exit reasons available? How are satisfaction scores collected? What other context is relevant? What privacy and fairness checks are required before using workforce analytics?
