-- Import CSV as hr_attrition.
SELECT COUNT(*) AS employee_count,
       SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS attrition_count,
       ROUND(100.0 * SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS attrition_rate_pct,
       ROUND(AVG(years_at_company), 2) AS average_tenure_years
FROM hr_attrition;

SELECT department, COUNT(*) AS employees,
       SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) AS attrition_count,
       ROUND(100.0 * SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS attrition_rate_pct
FROM hr_attrition GROUP BY department ORDER BY attrition_rate_pct DESC;

SELECT job_satisfaction_1_to_5, COUNT(*) AS employees,
       ROUND(100.0 * SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS attrition_rate_pct
FROM hr_attrition GROUP BY job_satisfaction_1_to_5 ORDER BY job_satisfaction_1_to_5;

SELECT overtime, COUNT(*) AS employees,
       ROUND(100.0 * SUM(CASE WHEN attrition = 'Yes' THEN 1 ELSE 0 END) / COUNT(*), 2) AS attrition_rate_pct
FROM hr_attrition GROUP BY overtime;
